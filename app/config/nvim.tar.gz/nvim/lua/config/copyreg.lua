vim.api.nvim_create_user_command("CR", function()
  local content = {}
  -- Get all buffer numbers
  for _, bufnr in ipairs(vim.api.nvim_list_bufs()) do
    -- Check if buffer is loaded and not hidden
    if vim.api.nvim_buf_is_loaded(bufnr) and vim.bo[bufnr].buflisted then
      local path = vim.api.nvim_buf_get_name(bufnr)
      -- Only add if it's a real file (not empty or untitled)
      if path and path ~= "" then
        -- Add file marker
        table.insert(content, "### File: " .. path)
        table.insert(content, "")
        -- Get and add file content
        local lines = vim.api.nvim_buf_get_lines(bufnr, 0, -1, false)
        for _, line in ipairs(lines) do
          table.insert(content, line)
        end
        table.insert(content, "")
        table.insert(content, "### End of file: " .. path)
        table.insert(content, "")
      end
    end
  end
  -- Join all content with newlines and copy to clipboard
  vim.fn.setreg("+", table.concat(content, "\n"))
  print("Copied " .. #content .. " lines to clipboard")
end, {})
