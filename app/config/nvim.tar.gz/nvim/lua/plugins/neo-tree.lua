return {
  "nvim-neo-tree/neo-tree.nvim",
  keys = {
    {
      "<leader>e",
      function()
        require("neo-tree.command").execute({ toggle = false, reveal = true })
      end,
      desc = "Explorer NeoTree (root dir)",
    },
  },
}
