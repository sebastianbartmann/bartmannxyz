return {
  "stevearc/aerial.nvim",
  opts = {},
  keys = {
    { "<leader>a", "<cmd>AerialToggle<cr>", desc = "Toggle Aerial" },
  },
}
